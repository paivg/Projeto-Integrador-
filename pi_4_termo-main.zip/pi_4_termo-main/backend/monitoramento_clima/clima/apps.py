from django.apps import AppConfig

class ClimaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'monitoramento_clima.clima'
    verbose_name = 'Monitoramento Climático'
